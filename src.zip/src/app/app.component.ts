import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'releas-note';
  newFunc = [
    { date: '2025-04-10', condition: true, note: 'Nova tela de relatórios' },
    {
      date: '2025-04-09',
      condition: false,
      note: 'Ajuste nos filtros de busca',
    },
    { date: '2025-04-08', condition: true, note: 'Exportar dados em CSV' },
  ];

  get activeFunc() {
    return this.newFunc.filter((f) => f.condition);
  }
}
