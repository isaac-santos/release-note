export interface Notification {
  id: number; // notification_id
  name: string;
  date: Date;
  note: string;
  created_at?: Date;
  created_by?: number;
  updated_at?: Date;
  updated_by?: number;
}
