import { Component, OnInit } from '@angular/core';
import { FuncService, Func } from './services/func.service';
import { DialogHistoryComponent } from './dialog-history/dialog-history.component';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent implements OnInit {
  title = 'releas-note';

  newFunc: Func[] = [];
  checked: Func[] = [];

  currentUserId = 123; // depois pegue do login real

  constructor(private dialog: MatDialog, private funcService: FuncService) {}

  ngOnInit(): void {
    this.funcService.getFuncs().subscribe((funcs) => {
      // Filtra funções que o usuário ainda não visualizou
      this.newFunc = funcs.filter(
        (f) => !f.viewedBy?.includes(this.currentUserId)
      );

      // Filtra funções que já foram visualizadas pelo usuário
      this.checked = funcs.filter((f) =>
        f.viewedBy?.includes(this.currentUserId)
      );
    });
  }

  moveToChecked(func: Func): void {
    const updatedFunc = {
      ...func,
      viewedBy: [...(func.viewedBy || []), this.currentUserId],
    };

    this.funcService.updateFunc(updatedFunc).subscribe((res) => {
      console.log('Resposta da atualização:', res);

      // Atualiza as listas
      this.newFunc = this.newFunc.filter((f) => f.id !== res.id); // Remove da lista de novas funções
      this.checked.push(res); // Adiciona à lista de funções vistas (checked)
    });
  }

  moveToActive(func: Func): void {
    const updatedFunc = {
      ...func,
      viewedBy: (func.viewedBy || []).filter((id) => id !== this.currentUserId),
    };

    this.funcService.updateFunc(updatedFunc).subscribe((res) => {
      console.log('Resposta da atualização:', res);

      this.checked = this.checked.filter((f) => f.id !== res.id);
      this.newFunc.push(res);
    });
  }

  get activeFunc() {
    return this.newFunc
      .filter((f) => !f.viewedBy?.includes(this.currentUserId))
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }

  openDialog(): void {
    this.dialog.open(DialogHistoryComponent, {
      data: this.checked,
    });
  }
}
