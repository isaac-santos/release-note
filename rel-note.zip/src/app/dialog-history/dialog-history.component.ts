import { Component, OnInit, Inject, AfterViewInit, ViewChild } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';

@Component({
  selector: 'app-dialog-history',
  templateUrl: './dialog-history.component.html',
  styleUrls: ['./dialog-history.component.css']
})
export class DialogHistoryComponent implements OnInit, AfterViewInit {
  displayedColumns: string[] = ['date', 'note'];
  dataSource: MatTableDataSource<any>;

  startDate: Date | null = null;
  endDate: Date | null = null;

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(@Inject(MAT_DIALOG_DATA) public data: any[]) {
    this.dataSource = new MatTableDataSource(this.data);
  }

  ngOnInit(): void {}

  ngAfterViewInit(): void {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;

    this.dataSource.sortingDataAccessor = (item, property) => {
      if (property === 'date') {
        return new Date(item.date).getTime();
      }
      return item[property];
    };

    this.sort.active = 'date';
    this.sort.direction = 'desc';
    this.sort.sortChange.emit();

    
  }

  applyDateFilter(): void {
    this.dataSource.data = this.data.filter((item) => {
      const itemDate = new Date(item.date).getTime();
      const start = this.startDate ? new Date(this.startDate).getTime() : null;
      const end = this.endDate ? new Date(this.endDate).getTime() : null;

      if (start && end) {
        return itemDate >= start && itemDate <= end;
      } else if (start) {
        return itemDate >= start;
      } else if (end) {
        return itemDate <= end;
      }

      return true;
    });

    this.dataSource.paginator?.firstPage();
  }

  clearDateFilter(): void {
    this.startDate = null;
    this.endDate = null;
    this.dataSource.data = this.data;
    this.dataSource.paginator?.firstPage();
  }
}
