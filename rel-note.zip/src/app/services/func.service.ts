import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface Func {
  id: number;
  date: string;
  note: string;
  viewedBy: number[];
  userId: number;
}

@Injectable({
  providedIn: 'root',
})
export class FuncService {
  private apiUrl = 'http://localhost:3000/funcs';

  constructor(private http: HttpClient) {}

  getFuncs(): Observable<Func[]> {
    return this.http.get<Func[]>(this.apiUrl);
  }

  updateFunc(func: Func): Observable<Func> {
    const url = `${this.apiUrl}/${func.id}`;
    return this.http.put<Func>(url, func);
  }
}
